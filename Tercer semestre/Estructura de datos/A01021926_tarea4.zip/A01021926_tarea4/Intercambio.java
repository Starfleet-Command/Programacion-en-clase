/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenamiento;
import java.util.ArrayList;

/**
 *
 * @author Juan Fco
 */
public class Intercambio {
    
    public static void imprimeLista(ArrayList<Persona> lista)
    {
        for(int k=0;k<lista.size();k++)
        {
            System.out.println(" "+lista.get(k).getNombre());
        }
        System.out.println("");
    }
    
    public static void imprimeEdad(ArrayList<Persona> lista)
    {
        for(int k=0;k<lista.size();k++)
        {
            System.out.println(" "+lista.get(k).getEdad());
        }
        System.out.println("");
    }
    
    protected static ArrayList<Persona> ordenaEdad(ArrayList<Persona> lel)
    {
        for(int r=0;r<lel.size()-1;r++)
        {
            if(lel.get(r+1).getEdad() < lel.get(r).getEdad())
            {
                Persona temp=lel.get(r+1);
                Persona temp2=lel.get(r);
                lel.remove(r+1);
                lel.remove(r);
                
                lel.add(r, temp);
                lel.add(r+1, temp2);
               
            }
            
        }
        return lel;
    }
    
    protected static ArrayList<Persona> ordenaNombre(ArrayList<Persona> lel)
    {
        for(int r=0;r<lel.size()-1;r++)
        {
            if(lel.get(r+1).getNombre().compareTo( lel.get(r).getNombre())<0)
            {
                Persona temp=lel.get(r+1);
                Persona temp2=lel.get(r);
                lel.remove(r+1);
                lel.remove(r);
                
                lel.add(r, temp);
                lel.add(r+1, temp2);
               
            }
            
        }
        return lel;
    }
    
    protected static ArrayList<Persona> ordenaApellido(ArrayList<Persona> lel)
    {
        for(int r=0;r<lel.size()-1;r++)
        {
            if(lel.get(r+1).getApellido().compareTo( lel.get(r).getApellido())<0)
            {
                Persona temp=lel.get(r+1);
                Persona temp2=lel.get(r);
                lel.remove(r+1);
                lel.remove(r);
                
                lel.add(r, temp);
                lel.add(r+1, temp2);
               
            }
            
        }
        return lel;
    }
    
    
}
