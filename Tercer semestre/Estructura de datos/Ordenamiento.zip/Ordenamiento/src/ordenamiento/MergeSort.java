
package ordenamiento;
import java.util.ArrayList;
/**
 *
 * @author Juan Fco
 */
public class MergeSort {
    
    
    protected static ArrayList<Persona> MergeSort(ArrayList<Persona> lista, int min,int max)
    {
        ArrayList<Persona> termino = new ArrayList();
        if(max>min)
        {
            int medio= (min+max)/2;
            MergeSort(lista,min,medio);
            MergeSort(lista,medio+1,max);
             termino= MergeEdad(lista,min,medio,max);
        }
        return termino;
    }
    
    protected static ArrayList<Persona> MergeEdad(ArrayList<Persona> lista,int min,int mitad,int max)
    {
        ArrayList<Persona> subUno= new ArrayList();
        ArrayList<Persona> subDos= new ArrayList();
        ArrayList<Persona> merged = new ArrayList();
        
        
        for(int u=min;u<mitad+1;u++)
        {
            Persona temp =lista.get(u);
            subUno.add(temp);
           
                    
        }
        
        for(int k=mitad+1;k<max;k++)
        {
            Persona temp2 =lista.get(k);
            subDos.add(temp2);
            
        }
        
        
        ;
        int contA=0;
        int contB=0;
        int merger=0;
        
        while(contA<subUno.size() && contB<subDos.size())
        {
            
        if(subUno.get(contA).getEdad()<subDos.get(contB).getEdad())
        {
            if(merged.size()==0)
            {
            merged.add(subUno.get(contA));
            }
            else merged.add(merger,subUno.get(contA));
            contA++;
        }
        else 
        {
            merged.add(merger, subDos.get(contB));
            contB++;
        }
        merger++;
        }
        
        while(contA<subUno.size())
        {
             merged.add(merger,subUno.get(contA));
            contA++;
            merger++;
        }
        
        while(contB<subDos.size())
        {
             merged.add(merger,subDos.get(contB));
            contB++;
            merger++;
        }
        
        return merged;
    }
}
