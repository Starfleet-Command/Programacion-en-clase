//
//  ViewController.swift
//  Calculadora
//
//  Created by Juan Francisco Gortárez Ricárdez on 10/18/17.
//  Copyright © 2017 Juan Francisco Gortárez Ricárdez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var NumeroPantalla:Double = 0
    var NumeroPrevio:Double = 0
    var PerformingMath = false
    var operation = 0;

    
    
    @IBOutlet weak var Display: UILabel!
    
    @IBAction func buttonpress(_ sender: UIButton) {
        if PerformingMath == true {
            Display.text = String(sender.tag)
            PerformingMath = false
        }
        else {
        
       Display.text = Display.text! + String(sender.tag)
       NumeroPantalla=Double(Display.text!)!
        }
        }
    
    @IBAction func buttons(_ sender: UIButton)
    {
        
        if Display.text != "" && sender.tag != 11 && sender.tag != 16
        {
            NumeroPrevio = Double(Display.text!)!
            
            if sender.tag == 12 //División
            {
                Display.text = "/";
            }
            else if sender.tag == 13 //Multiplicación
            {
                Display.text = "x";
            }
            else if sender.tag == 14 //Resta
            {
                Display.text = "-";
            }
            else if sender.tag == 15 //Suma
            {
                Display.text = "+";
            }
             operation = sender.tag
             PerformingMath = true;
        }
        
        
        else if sender.tag == 16
        {
            if operation == 12
            {
                Display.text = String(NumeroPrevio / NumeroPantalla)
            }
            else if operation == 13
            {
                Display.text = String(NumeroPrevio * NumeroPantalla)
            }
            else if operation == 14
            {
                Display.text = String(NumeroPrevio - NumeroPantalla)
            }
            else if operation == 15
            {
                Display.text = String(NumeroPrevio + NumeroPantalla)
            }
        }
        else if sender.tag == 11
        {
            Display.text = ""
            NumeroPrevio = 0;
            NumeroPantalla = 0;
            operation = 0;
            PerformingMath = false
        }
}



    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

