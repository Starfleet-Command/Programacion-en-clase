/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenamiento;

import java.util.ArrayList;

/**
 *
 * @author Juan Fco
 */
public class Seleccion {
    
    
    public static ArrayList<Persona> SeleccionEdad(ArrayList<Persona> lista)
    {
        int menor=0;
        
        for(int c=0; c<lista.size()-1;c++)
        {
            int posic=-1;
           Persona temp1=lista.get(c);
           menor=temp1.getEdad();
           for(int r=c; r<lista.size();r++)
           {
               if (lista.get(r).getEdad()<menor)
               {
                   menor=lista.get(r).getEdad();
                   posic=r;
               }
           }
           if(posic!=-1)
           {
           Persona temp2=lista.get(posic);
            lista.remove(posic);
           lista.remove(c);
                
                
                lista.add(c, temp2);
                lista.add(posic, temp1);
           }
        }
                
        
        return lista;
    }
    
    public static ArrayList<Persona> SeleccionNombre(ArrayList<Persona> lista)
    {
        String menor;
        
        for(int c=0; c<lista.size()-1;c++)
        {
            int posic=-1;
           Persona temp1=lista.get(c);
           menor=temp1.getNombre();
           for(int r=c; r<lista.size();r++)
           {
               if (lista.get(r).getNombre().compareTo(temp1.getNombre())<menor.compareTo(temp1.getNombre()))
               {
                   menor=lista.get(r).getNombre();
                   posic=r;
               }
           }
           if(posic!=-1)
           {
           Persona temp2=lista.get(posic); 
            lista.remove(posic);
           lista.remove(c);
                
                
                lista.add(c, temp2);
                lista.add(posic, temp1);
           }
        }
                
        
        return lista;
    }
    
    public static ArrayList<Persona> SeleccionApellido(ArrayList<Persona> lista)
    {
        String menor;
        
        for(int c=0; c<lista.size()-1;c++)
        {
           int posic=-1;
           Persona temp1=lista.get(c);
           menor=temp1.getApellido();
           for(int r=c; r<lista.size();r++)
           {
               if (lista.get(r).getApellido().compareTo(temp1.getApellido())<menor.compareTo(temp1.getApellido()))
               {
                   menor=lista.get(r).getApellido();
                   posic=r;
               }
           }
           if(posic!=-1)
           {
           Persona temp2=lista.get(posic);
            lista.remove(posic);
           lista.remove(c);
                
                
                lista.add(c, temp2);
                lista.add(posic, temp1);
           }
        }
                
        
        return lista;
    }
}
