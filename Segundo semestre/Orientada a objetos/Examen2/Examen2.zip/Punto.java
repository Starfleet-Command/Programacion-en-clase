public class Punto
{
  double x,y;
  

  public double getX()
  {
    return x;
  }

  public double gety()
  {
    return y;
  }

  public void printValores()
  {
    System.out.println("El valor de x es:  "+this.x);
    System.out.println("El valor de y es: "+this.y);
  }
}
