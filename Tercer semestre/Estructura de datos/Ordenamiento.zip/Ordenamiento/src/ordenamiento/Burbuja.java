/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenamiento;
import java.util.ArrayList;
/**
 *
 * @author Juan Fco
 */
public class Burbuja {
    
    protected static ArrayList<Persona> BurbujaEdad(ArrayList<Persona> arreglo)
    {
        for(int i=0; i<arreglo.size()-1;i++)
        {
            for(int r=0;r<arreglo.size()-i-1;r++)
            {
                if(arreglo.get(r).getEdad()>arreglo.get(r+1).getEdad())
                {
                   Persona temp = arreglo.get(r);
                   Persona temp2 = arreglo.get(r+1);
                   arreglo.remove(r+1);
                   arreglo.remove(r);
                   
                   arreglo.add(r,temp2);
                   arreglo.add(r+1,temp);
                }
                
            }
        }
        return arreglo;
    }
    
    
    protected static ArrayList<Persona> BurbujaNombre(ArrayList<Persona> arreglo)
    {
        for(int i=0; i<arreglo.size()-1;i++)
        {
            for(int r=0;r<arreglo.size()-i-1;r++)
            {
                if(arreglo.get(r).getNombre().compareTo(arreglo.get(r+1).getNombre())>0)
                {
                   Persona temp = arreglo.get(r);
                   Persona temp2 = arreglo.get(r+1);
                   arreglo.remove(r+1);
                   arreglo.remove(r);
                   
                   arreglo.add(r,temp2);
                   arreglo.add(r+1,temp);
                }
                
            }
        }
        return arreglo;
    }
    
     protected static ArrayList<Persona> BurbujaApellido(ArrayList<Persona> arreglo)
    {
        for(int i=0; i<arreglo.size()-1;i++)
        {
            for(int r=0;r<arreglo.size()-i-1;r++)
            {
                if(arreglo.get(r).getApellido().compareTo(arreglo.get(r+1).getApellido())>0)
                {
                   Persona temp = arreglo.get(r);
                   Persona temp2 = arreglo.get(r+1);
                   arreglo.remove(r+1);
                   arreglo.remove(r);
                   
                   arreglo.add(r,temp2);
                   arreglo.add(r+1,temp);
                }
                
            }
        }
        return arreglo;
    }
     
      protected static ArrayList<Persona> BurbujaTelefono(ArrayList<Persona> arreglo)
    {
        for(int i=0; i<arreglo.size()-1;i++)
        {
            for(int r=0;r<arreglo.size()-i-1;r++)
            {
                if(arreglo.get(r).getTelefono().compareTo(arreglo.get(r+1).getTelefono())>0)
                {
                   Persona temp = arreglo.get(r);
                   Persona temp2 = arreglo.get(r+1);
                   arreglo.remove(r+1);
                   arreglo.remove(r);
                   
                   arreglo.add(r,temp2);
                   arreglo.add(r+1,temp);
                }
                
            }
        }
        return arreglo;
    }
    
}
