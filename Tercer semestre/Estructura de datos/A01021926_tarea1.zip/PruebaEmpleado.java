public class PruebaEmpleado
{
  public static void main(String[] args)
  {
    Empleado emp1 = new Empleado("Jose Maria","2088",15000,200,100,0);
    emp1.printNomina(emp1);
  }
}
