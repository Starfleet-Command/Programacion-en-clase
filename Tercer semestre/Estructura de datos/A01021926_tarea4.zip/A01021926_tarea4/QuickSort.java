/*
 Elegir un elemento del arreglo, llamado pivote. Los elementos en el sub arreglo izquiero son menores que el pivote, y los del derecho son mayores. 
 */
package ordenamiento;
import java.util.ArrayList;
/**
 *
 * @author Juan Fco
 */
public class QuickSort {
        
    
    protected static ArrayList<Persona> QuickEdad(ArrayList<Persona> lista, int min,int max )
    {
        if(min<max)
        {
        int pivote = ParticionEdad(lista,min,max);
        QuickEdad(lista,min,pivote-1);
        QuickEdad(lista,pivote+1,max);
        }
        return lista;
    }
    
    protected static int ParticionEdad(ArrayList<Persona> lista, int low, int high)
    {
        
        
     
     int pivot = lista.get(high).getEdad();  
 
    int i = (low-1); 

    for (int j = low; j<high; j++)
    {
        
        if (lista.get(j).getEdad()<= pivot)
        {
            i++;    
            Persona temp = lista.get(i);
            Persona temp2 = lista.get(j);
                   lista.set(j, temp);
                   lista.set(i, temp2);
                  
        }
    }
                   Persona temp = lista.get(i+1);
                   Persona temp2 = lista.get(high);
                   lista.set(i+1,temp2);
                   lista.set(high,temp);    
    return (i+1);
    }
    
}
