/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenamiento;
import java.util.ArrayList;
/**
 *
 * @author Juan Fco
 */
public class Insercion {
    
    public static ArrayList<Persona> InsertEdad(ArrayList<Persona> lista)
    {
        ArrayList<Persona> temporal = new ArrayList<Persona>();
        
        for(int r=0;r<lista.size();r++)
        {
            temporal.add(lista.get(r));
            if(r>=1)
            {
                
               for(int u=r; u>=1;u--)
            {
                if(temporal.get(u).getEdad()<temporal.get(u-1).getEdad())
                {
                    Persona temp=temporal.get(u);
                Persona temp2=temporal.get(u-1);
                temporal.remove(temp2);
                temporal.remove(temp);
                
                temporal.add(u-1, temp);
                temporal.add(u, temp2);
                
                }
            }
            }
            
        }
        return temporal;
    }
    
    public static ArrayList<Persona> InsertApellido(ArrayList<Persona> lista)
    {
        ArrayList<Persona> temporal = new ArrayList<Persona>();
        
        for(int r=0;r<lista.size();r++)
        {
            temporal.add(lista.get(r));
            if(r>=1)
            {
                
               for(int u=r; u>=1;u--)
            {
                if(temporal.get(u).getApellido().compareTo(temporal.get(u-1).getApellido())<0)
                {
                    Persona temp=temporal.get(u);
                Persona temp2=temporal.get(u-1);
                temporal.remove(temp2);
                temporal.remove(temp);
                
                temporal.add(u-1, temp);
                temporal.add(u, temp2);
                
                }
            }
            }
            
        }
        return temporal;
    }
    
    public static ArrayList<Persona> InsertNombre(ArrayList<Persona> lista)
    {
        ArrayList<Persona> temporal = new ArrayList<Persona>();
        
        for(int r=0;r<lista.size();r++)
        {
            temporal.add(lista.get(r));
            if(r>=1)
            {
                
               for(int u=r; u>=1;u--)
            {
                if(temporal.get(u).getNombre().compareTo(temporal.get(u-1).getNombre())<0)
                {
                    Persona temp=temporal.get(u);
                Persona temp2=temporal.get(u-1);
                temporal.remove(temp2);
                temporal.remove(temp);
                
                temporal.add(u-1, temp);
                temporal.add(u, temp2);
                
                }
            }
            }
            
        }
        return temporal;
    }
}
