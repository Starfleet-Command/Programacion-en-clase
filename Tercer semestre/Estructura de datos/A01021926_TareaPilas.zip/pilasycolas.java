public interface pilasycolas {
    boolean push(Object elemento);
    boolean pop();
    Object top();
    boolean vaciar();
    boolean esVacia();
}
