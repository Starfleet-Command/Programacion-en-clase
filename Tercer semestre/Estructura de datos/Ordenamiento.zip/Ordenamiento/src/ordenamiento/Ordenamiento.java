/*
 
 */
package ordenamiento;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author Juan Fco
 */
public class Ordenamiento {

   
    public static void main(String[] args) {
        
      /*  DECLARACION DEL ARREGLO "DE PRUEBA" PARA COMPROBAR LOS METODOS
        
        
        ArrayList<Persona> arregloP = new ArrayList<Persona>();
        
        
        
       Persona people = new Persona("5534867307","Juan","Gortarez",17);
        Persona people2 = new Persona("5537261526","Samantha","Traynor",19);
        Persona people3 = new Persona("5547365281","Megumi","Kimura",325);
        Persona people4 = new Persona("5553628121","Miguel","Arreola",23);
        Persona people5 = new Persona("5546372514","Bob","El Constructor",27);
        arregloP.add(people);
        arregloP.add(people2);
        arregloP.add(people3);
        arregloP.add(people4);
        arregloP.add(people5);

       
         Intercambio(arregloP);
         Seleccion(arregloP);
         Insercion(arregloP);
         Burbuja(arregloP);
         QuickSort(arregloP);
         MergeSort(arregloP);

     
    */
      
      
       ArrayList<Persona> cienmil = cienMilPersonas(); //SE CREA UN ARRAYLIST DE 100,000 OBJETOS. 
      
      // SE PUEDE USAR EL METODO Intercambio.imprimeEdad(cienmil); PARA COMPROBAR QUE EL ARREGLO GENERADO ESTA DESORDENADO
      
      //------------------------ LLAMADAS A METODOS DE ORDENAMIENTO POR EDAD UNICAMENTE-----------------------------
      
      QuickEdad(cienmil);
      /*
      IntercambioEdad(cienmil);
      SeleccionEdad(cienmil);
      InsercionEdad(cienmil);
      BurbujaEdad(cienmil);

      MergeEdad(cienmil);
       */
      
      
      
      
        
    }
    //-------------METODOS DE ORDENAMIENTO POR TRES CARACTERISTICAS (ARREGLOS MAS CORTOS)-------------------------
    public static void Intercambio(ArrayList<Persona> arregloP)
    {
        System.out.println("INTERCAMBIO: ");
        ArrayList<Persona> arregloR = new ArrayList<Persona>();
        arregloR = Intercambio.ordenaEdad(arregloP);
        Intercambio.imprimeLista(arregloR);
        arregloR=Intercambio.ordenaNombre(arregloP);
        Intercambio.imprimeLista(arregloR);
        arregloR=Intercambio.ordenaApellido(arregloP);
        Intercambio.imprimeLista(arregloR);
    }
    
        public static void Seleccion(ArrayList<Persona> arregloP)
    {
        System.out.println("SELECCIÓN: ");
        ArrayList<Persona> arregloT = new ArrayList<Persona>();
        arregloT=Seleccion.SeleccionEdad(arregloP);
        Intercambio.imprimeLista(arregloT);
        arregloT=Seleccion.SeleccionNombre(arregloP);
        Intercambio.imprimeLista(arregloT);
        arregloT=Seleccion.SeleccionApellido(arregloP);
        Intercambio.imprimeLista(arregloT);
    }
        public static void Insercion(ArrayList<Persona> arregloP)
        {
            System.out.println("INSERCIÓN: ");
            ArrayList<Persona> arregloI = new ArrayList<Persona>();
            arregloI=Insercion.InsertEdad(arregloP);
            Intercambio.imprimeLista(arregloI);
            arregloI=Insercion.InsertNombre(arregloP);
            Intercambio.imprimeLista(arregloI);
            arregloI=Insercion.InsertApellido(arregloP);
            Intercambio.imprimeLista(arregloI);
        }
        
        public static void Burbuja(ArrayList<Persona> arregloP)
        {
            System.out.println("BURBUJA: ");
            ArrayList<Persona> arregloQ = new ArrayList<Persona>();
            arregloQ=Burbuja.BurbujaEdad(arregloP);
            Intercambio.imprimeLista(arregloQ);
            arregloQ=Burbuja.BurbujaNombre(arregloP);
            Intercambio.imprimeLista(arregloQ);
            arregloQ=Burbuja.BurbujaApellido(arregloP);
            Intercambio.imprimeLista(arregloQ);
            arregloQ=Burbuja.BurbujaTelefono(arregloP);
            Intercambio.imprimeLista(arregloQ);
        }
        
        public static void QuickSort(ArrayList<Persona> arregloP)
        {
            System.out.println("QUICKSORT");
            ArrayList<Persona> arregloU = new ArrayList<Persona>();
            arregloU=QuickSort.QuickEdad(arregloP,0,arregloP.size()-1);
            Intercambio.imprimeLista(arregloU);
            
        }
        
        public static void MergeSort(ArrayList<Persona> arregloP)
        {
            System.out.println("MERGESORT");
            ArrayList<Persona> arregloR = new ArrayList();
            arregloR= MergeSort.MergeSort(arregloP,0,arregloP.size());
            Intercambio.imprimeLista(arregloR);
        }
        
        public static ArrayList<Persona> cienMilPersonas()
        {
            Random r = new Random();
            ArrayList<Persona> lista = new ArrayList<Persona>();
            for(long k=0;k<100000;k++)
            {
                int aleat=r.nextInt(100);
                
                Persona u= new Persona(aleat); //USANDO PERSONA MODIFICADA CON SOLO EDAD
                lista.add(u);
            }
            return lista;
        }
        
        //-------------METODOS DE ORDENAMIENTO POR EDAD-------------------------
        
        public static void IntercambioEdad(ArrayList<Persona> arregloP)
        {
            ArrayList<Persona> arregloR= new ArrayList<Persona>();
           long inicial= System.nanoTime();
           arregloR = Intercambio.ordenaEdad(arregloP);
           long termino =System.nanoTime();
           double resta= (termino-inicial)/1000000000;
           System.out.println("Time elapsed (Intercambio): "+resta);
        }
        
         public static void SeleccionEdad(ArrayList<Persona> arregloP)
        {
            ArrayList<Persona> arregloT= new ArrayList<Persona>();
            long inicial= System.nanoTime();
            arregloT=Seleccion.SeleccionEdad(arregloP);
           long termino =System.nanoTime();
           double resta= (termino-inicial)/1000000000;
           System.out.println("Time elapsed (Seleccion): "+resta);
        }
         
          public static void InsercionEdad(ArrayList<Persona> arregloP)
        {
            ArrayList<Persona> arregloI= new ArrayList<Persona>();
            long inicial= System.nanoTime();
            arregloI=Insercion.InsertEdad(arregloP);
           long termino =System.nanoTime();
           double resta= (termino-inicial)/1000000000;
           System.out.println("Time elapsed (Insercion): "+resta);
        }
          
           public static void BurbujaEdad(ArrayList<Persona> arregloP)
        {
            ArrayList<Persona> arregloQ= new ArrayList<Persona>();
            long inicial= System.nanoTime();
           arregloQ=Burbuja.BurbujaEdad(arregloP);
           long termino =System.nanoTime();
           double resta= (termino-inicial)/1000000000;
           System.out.println("Time elapsed (Burbuja): "+resta);
        }

           
            public static void QuickEdad(ArrayList<Persona> arregloP)
        {
            ArrayList<Persona> arregloU= new ArrayList<Persona>();
            long inicial= System.nanoTime();
            arregloU=QuickSort.QuickEdad(arregloP,0,arregloP.size()-1);
           long termino =System.nanoTime();
           double resta= (termino-inicial);
           
           System.out.println("Time elapsed (QuickSort): "+resta);
        }
            
            public static void MergeEdad(ArrayList<Persona> arregloP)
            {
                ArrayList<Persona> arregloU= new ArrayList<Persona>();
            long inicial= System.nanoTime();
            arregloU=MergeSort.MergeSort(arregloP,0,arregloP.size());
           long termino =System.nanoTime();
           double resta= (termino-inicial)/1000000000;
            
           System.out.println("Time elapsed (MergeSort): "+resta);
            }
        
        
    
    
}
